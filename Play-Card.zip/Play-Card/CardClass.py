#encoding=utf-8
class Card(object):
	"""docstring for Card"""
	def __init__(self, cardId, num, name, type_):
		self.cardId = cardId
		self.num = num # 牌面大小
		self.name = name # 牌面名称
		self.type_ = type_ # 花色
		self.rules = {} # 每张牌所拥有的规则