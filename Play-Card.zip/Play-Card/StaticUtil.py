#encoding=utf-8

import CardClass
import TreeClass
import random

# 生成牌
def generateCards():
	cards = []
	cardNum = [1,2,3,4,5,6,7,8,9,10,11,12,15,20,21]
	cardNames = ['3','4','5','6','7','8','9','T','J','Q','K','A','2','X','D']
	cardTypes = ['#','$','%','*']
	cardId = 1
	for num,name in zip(cardNum, cardNames):
		if name != 'X' and name != 'D':
			for type_ in cardTypes:
				cards.append(CardClass.Card(cardId, num, name, type_))
				cardId += 1
		else:
			cards.append(CardClass.Card(cardId, num, name, ""))
			cardId += 1
	return cards

# 随机发牌
def distributeCard(cards, players):
	# 此处不留三张
	m = 0
	while len(cards) > 0:
		j = random.randint(0,len(cards) - 1)
		i = m % len(players)
		players[i].cards[cards[j].cardId] = cards[j]
		del cards[j]
		m += 1

# 排序
def sortCards(cards):
	sortedCards = sorted(cards.items(), key = lambda x:x[1].num)
	return sortedCards

# 对排序后的牌创建树集合
def createTreeSet(sortedCards):
	curNode = None
	treeSet = {} # 起始牌的牌面:tree
	# 遍历每张牌，
	for cardId,card in sortedCards:
		treeNode = TreeClass.TreeNode(0, card)
		if curNode == None:
			tree = None
		if curNode != None and curNode.card.num != treeNode.card.num and curNode.card.num + 1 != treeNode.card.num:
			tree = None
		if tree is None:
			rootNode = TreeClass.TreeNode(0, None)
			tree = TreeClass.Tree(rootNode) # 创建根
			curNode = rootNode
		# 如果牌和curNode的牌面不同,放到第一个子节点
		if curNode.card == None:
			treeSet[treeNode.card.num] = tree

		if curNode.card == None or curNode.card.num != card.num:
			curNode.mFirstChild = treeNode
			treeNode.mParentNode = curNode
			treeNode.mRightNode = treeNode
			treeNode.mLeftNode = treeNode
			curNode = treeNode
			tree.depth += 1
			curNode.curDepth = tree.depth
		else:
			# 相同牌面的牌放到同一层
			curNode.numOfBrother += 1
			treeNode.numOfBrother = curNode.numOfBrother
			tmpNode = curNode.mRightNode
			curNode.mRightNode = treeNode
			treeNode.mLeftNode = curNode
			treeNode.mRightNode = tmpNode
			tmpNode.mLeftNode = treeNode
			curNode.curDepth = tree.depth

		tree.mCards[treeNode.card.cardId] = treeNode.card
		tree.nodeCount += 1
	return treeSet