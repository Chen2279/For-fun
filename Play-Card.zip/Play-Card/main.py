#encoding=utf-8

import StaticUtil
import PlayerClass
import random
import sys

def oneGame(players, firstPlayerInx = 0):
	cards = StaticUtil.generateCards()
	StaticUtil.distributeCard(cards, players)

	# 为每个玩家创建规则
	print("-------Game start---------")
	for player in players:
		sortedCards = StaticUtil.sortCards(player.cards) #对牌排序
		# showCardsOfPlayer(sortedCards) # 打印牌
		treeSet = StaticUtil.createTreeSet(sortedCards) # 创建树集
		player.tree = treeSet
		player.showAllCards()
		# 从所有的子树中寻找规则
		startCards = sorted(treeSet.keys())
		for num in startCards:
			# {"single":[],"duizi":[],"tri":[],"singleSZ":[],"doubleSZ":[],"triSZ":[],"zhadan":[],"wangzha":[]}
			rules = treeSet[num].findRules()
			# 每个子树上的规则
			player.rules[num] = rules

	stepCount = 1
	print("---------Step " + str(stepCount) + "-----------")
	# 首发玩家打牌,返回打出牌的规则名称、起始牌、出牌深度、规则等级,并更新子树
	ruleName, startCard, depth, rulePriority,cardStr = players[firstPlayerInx].playRandom()
	for p in players:
		p.showAllCards()

	passCount = 0;score = 2;curIndex = firstPlayerInx + 1;stepCount += 1
	playerIndex = [0,1,2]
	isFinish = False
	totalCount = len(playerIndex) - 1
	while len(playerIndex) > 1:
		print("---------Step " + str(stepCount) + "-----------")
		# 玩家打完牌，统计其得分
		i = curIndex % (len(playerIndex))
		player = players[playerIndex[i]]

		# 如果两个玩家都不打牌，则为该玩家随机打牌
		if isFinish and passCount == 2:
			totalCount = len(playerIndex) - 1
			isFinish = False

		if passCount >= totalCount:
			ruleName,startCard,depth,rulePriority,cardStr = player.playRandom()
			passCount = 0
			curIndex += 1
			stepCount += 1
			if len(player.cards) == 0:
				print(player.name + " finish")
				isFinish = True
				curIndex = i
				del playerIndex[i]
				player.score += score
				score -= 1
			for p in players:
				p.showAllCards()
			continue

		isPlayCard = False # 该玩家是否打牌
		

		# 给一定的出牌概率
		if random.random() <= player.probility:
			# 遍历子树上的规则
			subTrees = sorted(player.rules.keys())
			for subTree in subTrees:
				# 判断是否存在该规则
				if len(player.rules[subTree][ruleName]) > 0:
					isPlayCard,ruleName,startCard,depth,rulePriority,cardStr = player.playCard(subTree, ruleName, startCard, depth)

					if isPlayCard:
						sortedCards = StaticUtil.sortCards(player.tree[subTree].mCards) #对牌排序
						treeSet = StaticUtil.createTreeSet(sortedCards) # 创建树集
						player.tree.pop(subTree)
						player.rules.pop(subTree)
						for num in treeSet:
							player.tree[num] = treeSet[num]
							rules = treeSet[num].findRules()
							player.rules[num] = rules
						passCount = 0
						print(player.name + " play " + cardStr)
						break
			if isPlayCard == False:
				print(player.name + " pass ")
				passCount += 1
		else:
			passCount += 1
			print(player.name + " pass ")

		for p in players:
			p.showAllCards()
		curIndex += 1
		stepCount += 1

		if len(player.cards) == 0:
			print(player.name + " finish")
			isFinish = True
			del playerIndex[i]
			player.score += score
			score -= 1
			curIndex = i
def main():
	playerA = PlayerClass.Player("A", 0, 0.96)
	playerB = PlayerClass.Player("B", 0, 0.96)
	playerC = PlayerClass.Player("C", 0, 0.96)
	players = [playerA, playerB, playerC]
	index = [0,1,2]
	for i in range(3):
		for player in players:
			player.clear()
		# 随机选一个玩家作为首发玩家,保证首发玩家不同
		print("--------------The " + str(i + 1) + " play------------------")
		m = random.randint(0,len(index) - 1)
		del index[m]
		oneGame(players, m)
	for player in players:
		print(player.name + ": " + str(player.score))

if __name__ == '__main__':
	main()