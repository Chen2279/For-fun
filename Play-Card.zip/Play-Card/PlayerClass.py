#encoding=utf-8
import StaticUtil
import random

class Player(object):
	"""docstring for self"""
	def __init__(self, name, attr, probility):
		self.name = name # 玩家名字
		# 玩家属性，可以定义玩家是真实的或者计算机 0-计算机 1-真人
		self.attr = attr 
		self.probility = probility # 出牌的概率
		self.score = 0 # 得分
		self.cards = {} # 玩家所有的牌
		self.tree = {} # 为每个玩家所有的牌建立子树集合
		self.rules = {} # 玩家所拥有的全部规则

	# 打印玩家牌面
	def showAllCards(self):
		cardsString = ""
		startCards = sorted(self.tree.keys())
		for num in startCards:
			cardsString += self.tree[num].scanTree()
		print(self.name + " hand " + cardsString)

	# 打牌
	def playCard(self, subTree, ruleName, startCard, depth, isRandom = False):
		isPlay = False
		cardStr = ""
		rules = self.rules[subTree][ruleName]
		numRule = len(rules)
		# print(ruleName)
		cur_startCard = startCard
		rulePriority = None
		for i in range(len(rules)):
			rule = rules[i]
			# 如果当前规则的起始牌小于前一个玩家的起始牌
			if startCard != None:
				if isRandom == False and rule.startCard.card.num <= startCard.card.num:
					continue

			rulePriority = rule.priority
			# 打牌
			# depth = rule.minDepth + numRule - 1
			curDepth = 1
			curNode = rule.startCard
			cur_startCard = curNode
			cardStr = ""
			if self.tree[subTree].depth - curNode.curDepth + 1 >= depth:
				while curDepth <= depth:
					try:
						tmpNode = curNode.mRightNode
					except Exception as e:
						print("cardStr " + cardStr)
					
					count = 1
					cardStr += curNode.card.name
					while count < rule.minCardCount:
						id_ = tmpNode.card.cardId
						cardStr += tmpNode.card.name
						# 删除打出的牌
						self.tree[subTree].mCards.pop(id_)
						self.cards.pop(id_)
						count += 1
						tmpNode = tmpNode.mRightNode
					id_ = curNode.card.cardId
					self.tree[subTree].mCards.pop(id_)
					self.cards.pop(id_)
					curNode = curNode.mFirstChild
					curDepth += 1
				# print("play " + cardStr)
				isPlay = True
				break
		return isPlay,ruleName,cur_startCard,depth,rulePriority,cardStr

	# 随意打牌
	def playRandom(self):
		subTrees = sorted(self.tree.keys())
		rulePlayOrder = ['triSZ','doubleSZ','singleSZ','tri','duizi','single','zhadan','wangzha'] # 规则的出牌顺序
		isPlay = False

		for subTree in subTrees:
			for order in rulePlayOrder:
				numRule = len(self.rules[subTree][order])
				# 如果该规则存在
				if numRule > 0:
					rules = self.rules[subTree][order]
					depth = rules[0].minDepth + numRule - 1
					if order in ['triSZ','doubleSZ','singleSZ']:
						isPlay,ruleName,startCard,depth,rulePriority,cardStr = self.playCard(subTree, order, None, depth, True)
					if order in ['tri','duizi','single']:
						isPlay,ruleName,startCard,depth,rulePriority,cardStr = self.playCard(subTree, order, None, rules[0].minDepth, True)
				if isPlay:
					break
			if isPlay:
				break
		if isPlay:
			# 对发生变化的子树重新构建树
			sortedCards = StaticUtil.sortCards(self.tree[subTree].mCards) #对牌排序
			treeSet = StaticUtil.createTreeSet(sortedCards) # 创建树集
			self.tree.pop(subTree)
			self.rules.pop(subTree)
			for num in treeSet:
				self.tree[num] = treeSet[num]
				rules = treeSet[num].findRules()
				self.rules[num] = rules
			print(self.name + " play " + cardStr)
		return ruleName,startCard,depth,rulePriority,cardStr

	def clear(self):
		self.cards.clear()
		self.tree.clear()
		self.rules.clear()