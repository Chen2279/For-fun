#encoding=utf-8

class Rule(object):
	"""docstring for Rule"""
	def __init__(self, ruleName, priority, minCardCount, minDepth = 1):
		self.ruleName = ruleName # 规则名称
		self.priority = priority # 规则的优先级
		# 1:单张 对子 三张 单顺子 双顺子 三顺子 1,2,3,4,5,6
		# 2:炸弹（4张相同的牌面）7
		# 3:王炸 8
		self.startCard = None # 规则开始的牌
		self.minCardCount = minCardCount #每层最少的牌数
		self.minDepth = minDepth
		self.cardIds = [] # 该规则所拥有的牌id