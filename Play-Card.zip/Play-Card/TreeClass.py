#encoding=utf-8
import RuleClass

# 把玩家所有的牌按大小构建一棵树，相同大小的放在同一层
class Tree(object):
	"""docstring for Tree"""
	def __init__(self, mRootNode):
		self.mRootNode = mRootNode # 根节点
		self.mCards = {} # 所有节点
		self.depth = 0
		self.nodeCount = 0

	# 遍历树
	def scanTree(self):
		curNode = self.mRootNode.mFirstChild
		cardsString = ""
		while curNode is not None:
			cardsString += curNode.card.name

			# 遍历同层的牌
			cardId = curNode.card.cardId
			tmpNode = curNode.mRightNode
			while tmpNode.card.cardId != cardId:
				cardsString += tmpNode.card.name
				tmpNode = tmpNode.mRightNode

			curNode = curNode.mFirstChild
		return cardsString

	# 寻找顺子规则
	def findRuleForSZ(self, curNode, startNode, curDepth, depth, minDepth):
		rule = None
		if minDepth == 2:
			minCount = 3 # 相同牌所需的数量
			ruleName = "triSZ"
			priority = 6
		elif minDepth == 3:
			minCount = 2
			ruleName = "doubleSZ"
			priority = 5

		# 如果深度达到顺子所需的最小深度，且数量达到最小要求，兄弟节点数量达到minCount
		if self.depth - curDepth + depth + 1 >= minDepth and self.nodeCount >= minCount * minDepth and curNode.numOfBrother >= minCount:
			depth += 1
		else:
			startNode = curNode.mFirstChild
			depth = 0
		if depth >= minDepth:
			rule = RuleClass.Rule(ruleName, priority, minCount, minDepth) # 添加顺子规则
			rule.startCard = startNode
			# startNode.card.rules[]
			startNode = curNode.mFirstChild # 该规则的起始节点
		return startNode,depth,rule

	# 寻找规则
	def findRules(self):
		rules = {"single":[],"duizi":[],"tri":[],"singleSZ":[],"doubleSZ":[],"triSZ":[],"zhadan":[],"wangzha":[]}
		curNode = self.mRootNode.mFirstChild
		curDepth = 1
		depth2 = 0 # 双顺子
		startNode2 = curNode
		depth3 = 0 # 三顺子
		startNode3 = curNode
		while curNode is not None:
			if curNode.numOfBrother >= 1:
				rule = RuleClass.Rule("single", 1, 1) # 添加单张规则
				rule.startCard = curNode
				rules["single"].append(rule)
			if curNode.numOfBrother >= 2:
				rule = RuleClass.Rule("duizi", 2, 2) # 添加对子规则
				rule.startCard = curNode
				rules["duizi"].append(rule)
			if curNode.numOfBrother >= 3:
				rule = RuleClass.Rule("tri", 3, 3) # 添加三张规则
				rule.startCard = curNode
				rules["tri"].append(rule)

			if curNode.numOfBrother >= 4:
				rule = RuleClass.Rule("zhadan", 7, 4) # 添加炸弹规则
				rule.startCard = curNode
				rules["zhadan"].append(rule)

			if curNode.card.name not in ['2','X','D']:
				if self.depth - curDepth + 1 >= 5:
					rule = RuleClass.Rule("singleSZ", 4, 1, 5) # 添加单顺子规则
					rule.startCard = curNode
					rules["singleSZ"].append(rule)

				startNode2,depth2,rule = self.findRuleForSZ(curNode, startNode2, curDepth, depth2, 3) # 添加双顺子规则
				if rule is not None:
					rules["doubleSZ"].append(rule)
				startNode3,depth3,rule = self.findRuleForSZ(curNode, startNode3, curDepth, depth3, 2) # 添加三顺子规则
				if rule is not None:
					rules["triSZ"].append(rule)

			if curNode.card.name == 'X' and curNode.mFirstChild != None and curNode.mFirstChild.card.name == 'D':
				rule = RuleClass.Rule("wangzha", 4, 1) # 添加王炸规则
				rule.startCard = curNode
				rules["wangzha"].append(rule)

			curNode = curNode.mFirstChild
			curDepth += 1
		return rules

class TreeNode(object):
	"""docstring for TreeNode"""
	def __init__(self, nodeId, card):
		self.nodeId = nodeId
		self.card = card # 牌
		self.mParentNode = None # 父节点
		self.mLeftNode = None # 左节点
		self.mRightNode = None # 右节点
		self.mFirstChild = None # 第一个子节点
		self.numOfBrother = 1 # 兄弟节点的个数
		self.curDepth = 1 # 节点所处的深度
		
		